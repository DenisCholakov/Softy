﻿namespace _02.VaniPlanning
{
    public enum Department
    {
        Sells = 1,
        Incomes = 2,
        Internals = 3,
        Wastage = 4,
        Others = 5
    }
}
