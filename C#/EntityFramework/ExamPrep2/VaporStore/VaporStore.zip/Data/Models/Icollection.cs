﻿namespace VaporStore.Data.Models
{
    public class Icollection<T>
    {
    }
}