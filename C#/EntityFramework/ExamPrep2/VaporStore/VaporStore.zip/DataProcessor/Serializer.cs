﻿namespace VaporStore.DataProcessor
{
	using System;
	using Data;

	public static class Serializer
	{
		public static string ExportGamesByGenres(VaporStoreDbContext context, string[] genreNames)
		{
			return "TODO";
		}

		public static string ExportUserPurchasesByType(VaporStoreDbContext context, string storeType)
		{
			return "TODO";
		}
	}
}