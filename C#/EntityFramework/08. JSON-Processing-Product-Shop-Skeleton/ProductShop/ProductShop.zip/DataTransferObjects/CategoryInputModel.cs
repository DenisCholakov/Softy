﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.DataTransferObjects
{
    public class CategoryInputModel
    {
        public string Name { get; set; }
    }
}
