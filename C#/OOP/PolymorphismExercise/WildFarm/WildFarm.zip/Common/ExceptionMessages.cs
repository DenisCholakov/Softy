﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Common
{
    public class ExceptionMessages
    {
        public const string InvalidType = "Invalid type";
    }
}
