﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding.Common
{
    public class ExceptionMessages
    {
        public const string InvalidHeroType = "Invalid hero!";
    }
}
