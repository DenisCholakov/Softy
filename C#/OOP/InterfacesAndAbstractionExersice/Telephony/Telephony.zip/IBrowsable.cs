﻿using System;


namespace Telephony
{
    public interface IBrowsable
    {
        public string Browse(string url);
    }
}
