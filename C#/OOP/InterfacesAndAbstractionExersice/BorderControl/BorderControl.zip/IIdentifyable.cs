﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public interface IIdentifyable
    {
        public string Id { get; }
    }
}
